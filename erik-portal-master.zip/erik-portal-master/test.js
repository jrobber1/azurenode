/**********************************
************TEST****FILE***********
**********************************/
const puppeteer = require('puppeteer');
const jsdom = require('jsdom');
const { JSDOM } = jsdom;
const util = require('util');
//library for Cleaning and Steralizing the HTML table data
const he = require('he');
let req = { body : {}};
req.body.courseCode = "201840";

function parseTime (str) {
  var result = {
      startHour: 0,
      startMinutes: 0,
      endHour: 0,
      endMinutes: 0
  };

  if (str.indexOf("-")) {
      var arr = str.replace(/\s/g, '').split("-");
      result.startHour = Math.floor(parseInt(arr[0]) / 100);
      result.startMinutes = parseInt(arr[0]) % 100;
      result.endHour = Math.floor(parseInt(arr[1]) / 100);
      result.endMinutes = parseInt(arr[1]) % 100;
  }

  return (result);
}
function getDayNumber (d) {
  switch (d) {
      case "M":
          dayNumber = 1;
          break;
      case "T":
          dayNumber = 2;
          break;
      case "W":
          dayNumber = 3;
          break;
      case "R":
          dayNumber = 4;
          break;
      case "F":
          dayNumber = 5;
          break;
      case "S":
          dayNumber = 6;
          break;
      
  }
  return (dayNumber);
}

(async () => {
  const browser = await puppeteer.launch({executablePath : "C:/Program Files (x86)/Google/Chrome/Application/chrome.exe"});
  const page = await browser.newPage();

  await page.goto("https:/ats.neit.edu/course/ClassSchedule_Search.asp");
		//Modify Form Inputs
		await page.select("[name=term]", `201840`);
		await page.$eval("[name=SubjCode1]", el => (el.value = "IT"));
		await page.$eval("[name=SubjCode2]", el => (el.value = "CYB"));
		await page.$eval("[name=SubjCode3]", el => (el.value = "VGD"));
		await page.$eval("[name=SubjCode4]", el => (el.value = "SE"));
		await page.$eval("[name=SubjCode5]", el => (el.value = "NE"));
		await page.$eval("[name=SubjCode6]", el => (el.value = "GDS"));
		//Submit Form
		await page.$eval("form", form => form.submit());
		//Gotta wrap it first, in jsdom
		// const dom = new JSDOM(await page.content()), { window } = dom;
		
		const { window } = new JSDOM(await page.content());
    console.log(window.document);
		//Function that handles organizing the data, just like pullSchedule
		//mongoose.connection.on('connected', createScheduleSchema);
		await (() => {
			
			var courses = [];

			var tr = window.document.getElementsByTagName("tbody")[0].children;
			var pointer = 5; //Skip the first 5 (header info)

			while (pointer < tr.length) {
				var course = {};
				//Serialize course data
				var courseInfoHTML = tr[pointer++].getElementsByTagName("td");
				course.id = he.decode(courseInfoHTML[0].innerHTML).trim();
				course.department = he.decode(courseInfoHTML[1].innerHTML).trim();
				course.code = he.decode(courseInfoHTML[2].innerHTML).trim();
				course.credits = he.decode(courseInfoHTML[3].innerHTML).trim();
				course.courseName = he.decode(courseInfoHTML[4].innerHTML).trim();
				course.instructor = he.decode(courseInfoHTML[5].innerHTML).trim();
        /*
        * Figured out the problem with the code here
        * (I actually encountered a similar issue in my JS class with for loops and variable declaration)
        * So, I guess in the new ECMAScript2016, you need do instantiate a variable with a specific declaritive keyword
        * otherwise, the javascript parser (V8 Engine, then, I guess) will instantiate the variable with the- 
        * -`const` declaritive keyword, thus polluting the global namespace.
        * and because javascript code is interpreted and executed from top to bottom, the /last/ write to the `enrollment`
        * variable is the value used when the submission is made to mongo.
        * 
        * the issue I experienced was I used the variable `i` in a for loop without an instantiator:
        * 
        *   ````JS`````````````````````
        *   ` function doALoop(){     `
        *   `   for(i=0;i<7;i++){     `
        *   `     //code executed here`
        *   `   }                     `
        *   ` }                       `
        *   ```````````````````````````
        * 
        * So when I went to use another for-loop later in my code, like so
        * 
        *   ```JS````````````````````
        *   ` for(i=0;i<5;i++){     `
        *   `    doALoop();         `
        *   ` }                     `
        *   `````````````````````````
        * 
        * The compiler executed the first instance like this
        * 
        *   ````JS`````````````````````````````````````````
        *   ` for(i=0;i<5;i++){                           `
        *   ` //i=0                                       `
        *   `   for(i=0;i<7;i++){                         `
        *   `     //code executed here                    `
        *   `   }                                         `
        *   ` //i=7                                       `
        *   ` //now the next time the compiler            `
        *   ` //executes the loop                         `
        *   ` //the var `i` is already 7,                 `
        *   ` //so the condition i<5 evaluates to false   `
        *   ` //and the loop is ceased                    `
        *   ` }                                           `
        *   ```````````````````````````````````````````````
        * 
        * which is what happened here with the line:
        * 
        *      _________________________________________________________________
        *     |                                                                 |
        *     | enrollment = courseInfoHTML[6].getElementsByTagName("td");      |
        *     |                                                                 |
        *      ‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾
        * (Note that if 'use strict' was inserted at the top of the document, th-)
        * (-is line would throw a ReferenceError exception.                      )
        * 
        * Which can be fixed by using:
        * 
        *      _________________________________________________________________
        *     |                                                                 |
        *     | var enrollment = courseInfoHTML[6].getElementsByTagName("td");  |
        *     |                                                                 |
        *      ‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾
        * (Note, var is to be depreciated soon, please use let or const)
        * (and that varaibles declared with var are confined to the current execution context)
        * Or:
        *      _________________________________________________________________
        *     |                                                                 |
        *     | let enrollment = courseInfoHTML[6].getElementsByTagName("td");  |
        *     |                                                                 |
        *      ‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾
        * which is better as:
        *      ____________________________________________________________________________
        *     |                                                                            |
        *     | let enrollment = courseInfoHTML[6].querySelectorAll("table tbody tr td");  |
        *     |                                                                            |
        *      ‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾
        */
        
        //enrollment = courseInfoHTML[6].getElementsByTagName("td");
        let enrollment = courseInfoHTML[6].querySelectorAll("table tbody tr td");
        var enrollmentData = {
          available : courseInfoHTML[6].querySelectorAll("table tbody tr td")[0].innerHTML,
          current : courseInfoHTML[6].querySelectorAll("table tbody tr td")[2].innerHTML,
          capacity : courseInfoHTML[6].querySelectorAll("table tbody tr td")[4].innerHTML,
        };
        console.table( enrollmentData );

				course.available = he.decode(enrollment[0].innerHTML).trim();
				course.current = he.decode(enrollment[2].innerHTML).trim();
				course.capacity = he.decode(enrollment[4].innerHTML).trim();

				course.classes = [];

				while (tr[pointer].innerHTML != '<td colspan="8"><hr></td>') {
					if (tr[pointer].innerHTML != "") {
						var classHTML = tr[pointer++];
						var days = classHTML.children[1].getElementsByTagName("td");

						var day;
						//Get day met
						for (var d = 0; d < days.length; d++) {
							if (days[d].innerHTML != "&nbsp;") {
								day = days[d].innerHTML;
								//Changed 'break' to continue
								//because for AS Capstone on W both days are listed
								// on the same line
								continue;
							}
						}
						//Serialize the class info object
						var classObj = {};
						classObj.day = day;
						classObj.dayNumber = getDayNumber(day);
						classObj.time = classHTML.children[2].innerHTML;
						classObj.room = classHTML.children[3].innerHTML;
						classObj.startDate = new Date(classHTML.children[4].innerHTML);
						classObj.startDate.setHours(0);
						classObj.startDate.setMinutes(0);
						classObj.startDate.setSeconds(0);
						classObj.endDate = new Date(classHTML.children[5].innerHTML);
						classObj.endDate.setHours(0);
						classObj.endDate.setMinutes(0);
						classObj.endDate.setSeconds(0);
						course.classes[course.classes.length] = classObj;
					} else {
						pointer++;
					}
				}

				courses[courses.length] = course;
				//skip over formatting
				pointer += 2;
			}
      //console.log("courses");
			//console.table(courses);

			for (var i = 0, len = courses.length; i < len; i++) {
				for (var j = 0, len2 = courses[i].classes.length; j < len2; j++) {
					department = courses[i].department.replace(/\&nbsp\;/g, "");
					//This doesnt work;
					courseName = courses[i].courseName.replace(/\&nbsp\;/g, "");
					//courseName = he.decode(courses[i].courseName);
					t = parseTime(courses[i].classes[j].time);
					courses[i].classes[j].startHour = (Number)(t.startHour);
					courses[i].classes[j].startMinutes = (Number)(t.startMinutes);
					courses[i].classes[j].endHour = (Number)(t.endHour);
					courses[i].classes[j].endMinutes = (Number)(t.endMinutes);
					courses[i].instructor = courses[i].instructor.replace(/<br>/gi, ", ");

					// parse courses[i].code
					courseNumber = "";
					sectionNumber = 0;
					if (courses[i].code.indexOf(".")) {
						var arr = courses[i].code.replace(/\s/g, "").split(".");
						courseNumber = department + " " + arr[0];
						sectionNumber = arr[1];
					}
					try{
						/*console.table(
							[req.body.courseCode,
							courseNumber,
							courseName,
							sectionNumber,
							courses[i].instructor,
							course.available,
							course.current,
							course.capacity,
							courses[i].classes[j].day,
							courses[i].classes[j].dayNumber,
							courses[i].classes[j].time,
							courses[i].classes[j].room,
							courses[i].classes[j].startDate,
							courses[i].classes[j].endDate,
							courses[i].classes[j].startHour,
							courses[i].classes[j].startMinutes,
							courses[i].classes[j].endHour,
							courses[i].classes[j].endMinutes]
              );
              */
					}catch(e){
						console.log('Room Broke');
						console.error(e);
					}
					
					
				}
				  
				  try{
            /*
            console.table(
						[req.body.courseCode,
						courseNumber,
						courseName,
						sectionNumber,
						courses[i].instructor,
						course.available,
						course.current,
						course.capacity,
						courses[i].classes]
            );
            */
				  }catch(e){
					console.log('Course Broke');
					console.error(e);
				  }
				  
					//console.log(courses[i].instructor, courseNumber);
				}
			})();


		//Screenshot for proof
		//await page.screenshot({ path: "proof.png" });
		//close browser
		await browser.close();
		//send success
})();