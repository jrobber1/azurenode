const d = document;
const log = console.log;
let today = new Date();


function simulateClick(x) {
  var event = new MouseEvent('click', {
    view: window,
    bubbles: true,
    cancelable: true
  });
  var cb = document.querySelector(x);
  var cancelled = !cb.dispatchEvent(event);
  if (cancelled) {
    // A handler called preventDefault.
    console.log("cancelled");
  } else {
    // None of the handlers called preventDefault.
    console.log('Got data')
  }
}

function getFormData() {
  var data = {};

  data.sort = d.querySelector("#sort").value;
  data.day = d.querySelector("[name=day]:checked").value;
  data.date = d.querySelector("[name=date]").value;
  data.time = d.querySelector("[name=time]").value;
  data.room = d.querySelector("[name=room]").value;
  data.instructorName = d.querySelector("[name=instructorName]").value;
  return data;
}

function simulateInput(on) {
  var event = new InputEvent({
    view: window,
    bubbles: true,
    cancelable: true
  })
  var cb = document.querySelector(on);
  var cancelled = !cb.dispatchEvent(event);
  if (cancelled) {
    // A handler called preventDefault.
    console.log("cancelled");
  } else {
    // None of the handlers called preventDefault.
    while (document.querySelector("#results").firstChild) {
      document.querySelector("#results").removeChild(document.querySelector("#results").firstChild);
    }
    sendData(getFormData());
  }
}

//Get the day of the week
const weekDay = (num = '') => {
  if (num == '') {
    num = new Date().getDay();
  }
  let datStr = '';
  switch (num) {
    case 0:
      //sunday
      dayStr = "sunday";
      break;
    case 1:
      //monday
      dayStr = "monday";
      break;
    case 2:
      //tuesday
      dayStr = "tuesday";
      break;
    case 3:
      //wednesday
      dayStr = "wednesday";
      break;
    case 4:
      //thursday
      dayStr = "thursday";
      break;
    case 5:
      //friday
      dayStr = "friday";
      break;
    case 6:
      //saturday
      dayStr = "saturday";
      break;
  }
  return dayStr;
};


//These are things set at page load
d.querySelector(`#${weekDay()}`).setAttribute("checked", "checked");

d.querySelector("#date").defaultValue = `${today.getFullYear()}-${(String)(today.getMonth() + 1).padStart(2, "0")}-${today.getDate()}`;
d.querySelector(`#time`).value = `${new Date().getHours()}:${new Date().getMinutes()}`

//Just realized these two set-timeouts don't really do anything, because they're counting down exactly one hour from when the page loads
//instead of one hour relative to the current time zone, and earth

//Deemed this unnecessary for now
/*
//This updates the form autfill every day
setTimeout( ()=>{
    today = new Date();
    d.querySelector(`#${weekDay()}`).setAttribute("checked", "checked");
    d.querySelector("#date").defaultValue = `${today.getFullYear()}-${(String)(today.getMonth()+1).padStart(2,"0")}-${today.getDate()}`;
}, 86400000 );
*/

//this updates the form autfill every hour
//Cut this down to a half hour, sensible time to update page data
setTimeout(() => {
  today = new Date();
  d.querySelector(`#time`).value = `${today.getHours()}:${today.getMinutes()}`
}, 1800000);

class Table {
  constructor(obj, ctx) {
    this.raw = obj;
    //When called, should fill in the table with the data
    if (document.querySelector(ctx).tagName != "TBODY") {
      this.$ = document.querySelector(`${ctx} tbody`);
    } else this.$ = document.querySelector(ctx);

    this.raw.forEach((elem) => {
      let tr = document.createElement("tr");

      for (var prop in elem) {
        let $td = document.createElement("td");
        let txt = `${elem[prop]}`;

        //Supply conditions here, to exclude certain rows
        //First, skip conditions
        if (prop == '_id' || prop == 'startMinutes' || prop == 'endMinutes' || prop == 'day' || prop == 'courseName') {
          continue;
        } else if (prop == 'instructorName') {
          let $txt = document.createTextNode(txt);
          $td.appendChild($txt);
          tr.appendChild($td);
        } else if (prop == 'room') {
          let $txt = document.createTextNode(txt);
          $td.appendChild($txt);
          tr.appendChild($td);
        } else if (prop == 'current') {
          //Ah
          //txt+=`${elem.current}`;
          let $txt = document.createTextNode(txt);
          $td.appendChild($txt);
          tr.appendChild($td);
          continue;
        } else if (prop == 'courseID') {
          txt += ` ${elem.courseName}`;
          let $txt = document.createTextNode(txt);
          $td.appendChild($txt);
          tr.appendChild($td);
          continue;
        } else if (prop == 'startHour') {
          txt += `:${elem.startMinutes}`;
          let $txt = document.createTextNode(txt);
          $td.appendChild($txt);
          tr.appendChild($td);
          continue;
        } else if (prop == 'endHour') {
          txt += `:${elem.endMinutes}`;
          let $txt = document.createTextNode(txt);
          $td.appendChild($txt);
          tr.appendChild($td);
          continue;
        } else {
          let $txt = document.createTextNode(txt);
          $td.appendChild($txt);
          tr.appendChild($td);
          continue;
        }
      }

      this.$.appendChild(tr);
    });
  }
}

//XHR Request Handler, REUSABLE
function sendData(data) {
  var XHR = new XMLHttpRequest();
  var urlEncodedData = "";
  var urlEncodedDataPairs = [];
  var name;

  // Turn the data object into an array of URL-encoded key/value pairs.
  for (name in data) {
    urlEncodedDataPairs.push(encodeURIComponent(name) + '=' + encodeURIComponent(data[name]));
  }

  // Combine the pairs into a single string and replace all %-encoded spaces to 
  // the '+' character; matches the behaviour of browser form submissions.
  urlEncodedData = urlEncodedDataPairs.join('&').replace(/%20/g, '+');

  // Define what happens on successful data submission
  XHR.addEventListener('load', function (event) {
    //alert('Yeah! Data sent and response loaded.');
    try {
      var data = JSON.parse(XHR.response);
    } catch (e) {
      console.log("Error parsing XHR response as JSON: " + e);
      log("Response body" + XHR.response)
    }


    var $table = new Table(data, "#results");

    console.log(data);
    console.log(XHR);
  });

  // Define what happens in case of error
  XHR.addEventListener('error', function (event) {
    alert('Oops! Something goes wrong.');
  });

  // Set up our request
  XHR.open('POST', '/search');

  // Add the required HTTP header for form data POST requests
  XHR.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');

  // Finally, send our data.
  XHR.send(urlEncodedData);
}

//Hidden input to handle sorting, much less confusing than before
d.querySelector("#sort").oninput = function (e) {
  while (document.querySelector("#results").firstChild) {
    document.querySelector("#results").removeChild(document.querySelector("#results").firstChild);
  }
  sendData(getFormData(sort = this.value));
};
//Handles a click and updates the hidden `#sort` element
d.querySelector("#sortByA").onclick = function (e) {
  d.querySelector("#sort").value = "instructorName";
  simulateInput("#sort");
};
//Handles a click and updates the hidden `#sort` element
d.querySelector("#sortByB").onclick = (e) => {
  d.querySelector("#sort").value = "room";
  simulateInput("#sort");
};
//Handles form submission button
d.querySelector("form").onsubmit = function (e) {
  e.preventDefault();
  while (document.querySelector("#results").firstChild) {
    document.querySelector("#results").removeChild(document.querySelector("#results").firstChild);
  }
  sendData(getFormData());
};

//Using these two functions, it is possible to have it so that when the date changes, the day changes
// and vise versa
//for now we'l leave it out
d.querySelectorAll("[name=day]").forEach((e) => {
  e.onclick = function (e) {
    while (document.querySelector("#results").firstChild) {
      document.querySelector("#results").removeChild(document.querySelector("#results").firstChild);
    }
    sendData(getFormData());
  };
})
d.querySelector("[name='date']").oninput = (e) => {

  //d.querySelector(`#${weekDay((new Date(e.target.value).getDay()+1))}`).setAttribute("checked", "checked");
  while (document.querySelector("#results").firstChild) {
    document.querySelector("#results").removeChild(document.querySelector("#results").firstChild);
  }

  sendData(getFormData());
}

simulateClick("#sortByB");