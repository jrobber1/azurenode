# erik-portal
[![Build Status](https://travis-ci.com/ianfabs/erik-portal.svg?token=tqsBzCK8P6TrRuYEQUF3&branch=master)](https://travis-ci.com/ianfabs/erik-portal)


A portal to retrieve and query NEIT search data
