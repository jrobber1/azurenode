const express = require("express");
const router = express.Router();
const { log } = console;
const mongoose = require("mongoose");
const { Room } = require("../schemas/Schedule");
const { Schedule } = require("../schemas/Schedule");
const { Types } = require('mongoose').Schema;
const util = require('util');

mongoose.connect("mongodb://erik:password4@ds217452.mlab.com:17452/heroku_vbct5f60");


router.get("/", async (req, res, next) => {
  try {
    await res.render('search', { title: "Search" });
  } catch (e) {
    next(e);
  }
});

//Changed to AJAX 
router.post("/", async (req, res, next) => {
  try {
    //Query Builder
    let query = Room.find({});
    if (req.body.day) {
      query.where('day').equals(req.body.day);
    }
    if (req.body.date) {
      log(req.body.time);
      now = new Date(req.body.date);
      log(now);
      //local config should be 4
      //now.setHours(24);
      //server config should be zero
      //now.setHours(4)
      now.setHours(4);
      log(now);
      query.and([
        {
          $or: [
            {
              $and: [
                { startDate: { $lte: now } },
                { endDate: { $gte: now } }
              ]
            },
            {
              $and: [
                { startDate: now },
                { endDate: now }
              ]
            }

          ]
        }
      ]);
    }
    if (req.body.time) {
      time = req.body.time + ":0";
      h = time.split(":")[0], m = time.split(":")[1];
      query.and([
        {
          $or: [
            {
              $and: [
                { startHour: h },
                { startMinutes: { $lte: m } }
              ]
            },
            {
              $and: [
                { endHour: h },
                { endMinutes: { $gte: m } }
              ]
            },
            {
              $and: [
                { startHour: { $lt: h } },
                { endHour: { $gt: h } }
              ]
            },
          ]
        }
      ]);
    }
    if (req.body.instructorName) {
      query.where("instructorName").regex(`${req.body.instructorName}`);
    }
    if (req.body.room) {
      query.where("room").regex(`${req.body.room}`);
    }
    if (req.body.sort) {
      query.sort(`${req.body.sort}`);
    }
    //for testing
    log(  util.inspect(query._conditions, {colors: true, depth: null})   );
    query.select("instructorName day room current courseID courseName startHour startMinutes endHour endMinutes");
    await query.exec((err, rooms) => {
      if (err) return console.log(err);
      log(rooms)
      res.json(rooms);
    })
  } catch (e) {
    next(e);
  }
});

module.exports = router;
