  // Bring Mongoose into the project
  var mongoose = require( 'mongoose' );
var scheduleSchema = new mongoose.Schema({
    termId: String,
    courseID: String,
    courseName: String, 
    sectionNumber: String, 
    available: Number,
    current: Number,
	capacity: Number,
	instructorName: String ,
	dayDetails: [{ day: String, 
		dayNumber: String,
		time: String,
		room: String,
		startDate: Date,
		endDate: Date,
		startHour: Number, 
		startMinutes: Number, 
		endHour: Number, 
		endMinutes: Number }]
     
    
  });
  
//Schedule = mongoose.model('Schedule', scheduleSchema);

var roomSchema = new mongoose.Schema({
	termId: String,
	courseID: String,
	courseName: String, 
	sectionNumber: String, 
	available: Number,
	current: Number,
capacity: Number,
instructorName: String ,
day: String, 
	dayNumber: String,
	time: String,
	room: String,
	startDate: Date,
	endDate: Date,
	startHour: Number, 
	startMinutes: Number, 
	endHour: Number, 
	endMinutes: Number 

});

//Room = mongoose.model('Room', roomSchema);
module.exports = {
	Room: mongoose.model('Room', roomSchema),
	Schedule: mongoose.model('Schedule', scheduleSchema)
};